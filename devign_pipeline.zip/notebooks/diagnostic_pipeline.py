"""
Diagnostic script for BiGRU Devign Data Pipeline.

Checks:
1. PAD token percentage per split
2. UNK token percentage per split
3. Sequence length distribution by class (vulnerable vs non-vulnerable)
4. Sample sequences for visual verification
5. pos_weight calculation for class imbalance

Usage:
    python diagnostic_pipeline.py --data_dir <path_to_processed_data>
"""

import os
import sys
import json
import argparse
import numpy as np
from pathlib import Path
from collections import defaultdict

sys.path.insert(0, str(Path(__file__).parent.parent))

# Default paths
DEFAULT_DATA_DIR = "F:/Work/C Vul Devign/Dataset/devign_final"
DEFAULT_OUTPUT_DIR = "F:/Work/C Vul Devign/output/"


def load_vocab(data_dir: str) -> dict:
    """Load vocabulary from JSON file."""
    vocab_path = os.path.join(data_dir, 'vocab.json')
    if not os.path.exists(vocab_path):
        raise FileNotFoundError(f"Vocabulary not found: {vocab_path}")
    
    with open(vocab_path, 'r') as f:
        vocab = json.load(f)
    return vocab


def load_config(data_dir: str) -> dict:
    """Load preprocessing config."""
    config_path = os.path.join(data_dir, 'config.json')
    if os.path.exists(config_path):
        with open(config_path, 'r') as f:
            return json.load(f)
    return {}


def load_split_data(data_dir: str, split: str) -> dict:
    """Load npz data for a split."""
    npz_path = os.path.join(data_dir, f'{split}.npz')
    if not os.path.exists(npz_path):
        raise FileNotFoundError(f"Data not found: {npz_path}")
    
    data = np.load(npz_path, allow_pickle=True)
    return {
        'input_ids': data['input_ids'],
        'attention_mask': data['attention_mask'],
        'labels': data['labels'],
    }


def get_id2token(vocab: dict) -> dict:
    """Reverse vocab to id->token mapping."""
    return {v: k for k, v in vocab.items()}


def calculate_token_stats(input_ids: np.ndarray, attention_mask: np.ndarray, 
                          pad_id: int, unk_id: int) -> dict:
    """Calculate PAD and UNK token percentages."""
    total_tokens = input_ids.size
    
    real_tokens_mask = (attention_mask == 1)
    total_real_tokens = real_tokens_mask.sum()
    
    pad_count = (input_ids == pad_id).sum()
    pad_pct = 100.0 * pad_count / total_tokens
    
    real_input_ids = input_ids[real_tokens_mask]
    unk_count = (real_input_ids == unk_id).sum()
    unk_pct = 100.0 * unk_count / total_real_tokens if total_real_tokens > 0 else 0.0
    
    return {
        'total_tokens': int(total_tokens),
        'total_real_tokens': int(total_real_tokens),
        'pad_count': int(pad_count),
        'pad_pct': float(pad_pct),
        'unk_count': int(unk_count),
        'unk_pct': float(unk_pct),
    }


def calculate_length_distribution(attention_mask: np.ndarray, labels: np.ndarray) -> dict:
    """Calculate sequence length distribution by class."""
    lengths = attention_mask.sum(axis=1)
    
    class_0_mask = (labels == 0)
    class_1_mask = (labels == 1)
    
    lengths_class_0 = lengths[class_0_mask]
    lengths_class_1 = lengths[class_1_mask]
    
    def get_stats(arr):
        if len(arr) == 0:
            return {'count': 0, 'mean': 0, 'std': 0, 'min': 0, 'max': 0, 
                    'p25': 0, 'p50': 0, 'p75': 0}
        return {
            'count': int(len(arr)),
            'mean': float(np.mean(arr)),
            'std': float(np.std(arr)),
            'min': int(np.min(arr)),
            'max': int(np.max(arr)),
            'p25': float(np.percentile(arr, 25)),
            'p50': float(np.percentile(arr, 50)),
            'p75': float(np.percentile(arr, 75)),
        }
    
    return {
        'all': get_stats(lengths),
        'non_vulnerable': get_stats(lengths_class_0),
        'vulnerable': get_stats(lengths_class_1),
    }


def decode_sequence(input_ids: np.ndarray, attention_mask: np.ndarray, 
                    id2token: dict, max_display: int = 50) -> str:
    """Decode input IDs to token string."""
    real_len = attention_mask.sum()
    tokens = []
    for i, token_id in enumerate(input_ids[:real_len]):
        token = id2token.get(int(token_id), f"[ID={token_id}]")
        tokens.append(token)
        if len(tokens) >= max_display:
            tokens.append("...")
            break
    return " ".join(tokens)


def get_sample_sequences(input_ids: np.ndarray, attention_mask: np.ndarray, 
                        labels: np.ndarray, id2token: dict, 
                        n_samples: int = 3) -> dict:
    """Get sample sequences for each class."""
    samples = {'non_vulnerable': [], 'vulnerable': []}
    
    class_0_indices = np.where(labels == 0)[0]
    class_1_indices = np.where(labels == 1)[0]
    
    rng = np.random.default_rng(42)
    
    if len(class_0_indices) > 0:
        sample_idx = rng.choice(class_0_indices, min(n_samples, len(class_0_indices)), replace=False)
        for idx in sample_idx:
            decoded = decode_sequence(input_ids[idx], attention_mask[idx], id2token)
            length = int(attention_mask[idx].sum())
            samples['non_vulnerable'].append({
                'index': int(idx),
                'length': length,
                'tokens': decoded
            })
    
    if len(class_1_indices) > 0:
        sample_idx = rng.choice(class_1_indices, min(n_samples, len(class_1_indices)), replace=False)
        for idx in sample_idx:
            decoded = decode_sequence(input_ids[idx], attention_mask[idx], id2token)
            length = int(attention_mask[idx].sum())
            samples['vulnerable'].append({
                'index': int(idx),
                'length': length,
                'tokens': decoded
            })
    
    return samples


def calculate_pos_weight(train_labels: np.ndarray) -> dict:
    """Calculate pos_weight for BCEWithLogitsLoss / CrossEntropyLoss."""
    n_total = len(train_labels)
    n_pos = (train_labels == 1).sum()
    n_neg = (train_labels == 0).sum()
    
    pos_weight = n_neg / n_pos if n_pos > 0 else 1.0
    
    class_weights = [1.0, pos_weight]
    
    pos_ratio = n_pos / n_total if n_total > 0 else 0.0
    
    return {
        'n_total': int(n_total),
        'n_positive': int(n_pos),
        'n_negative': int(n_neg),
        'pos_ratio': float(pos_ratio),
        'neg_ratio': float(1 - pos_ratio),
        'pos_weight': float(pos_weight),
        'class_weights': [float(w) for w in class_weights],
        'recommended_weight_tensor': f"torch.tensor([1.0, {pos_weight:.4f}])"
    }


def analyze_token_distribution(input_ids: np.ndarray, attention_mask: np.ndarray,
                               id2token: dict, top_k: int = 20) -> dict:
    """Analyze token frequency distribution (excluding PAD)."""
    real_tokens_mask = (attention_mask == 1)
    real_tokens = input_ids[real_tokens_mask]
    
    unique, counts = np.unique(real_tokens, return_counts=True)
    sorted_idx = np.argsort(-counts)
    
    top_tokens = []
    for i in sorted_idx[:top_k]:
        token_id = int(unique[i])
        token = id2token.get(token_id, f"[ID={token_id}]")
        count = int(counts[i])
        pct = 100.0 * count / len(real_tokens) if len(real_tokens) > 0 else 0.0
        top_tokens.append({
            'token': token,
            'id': token_id,
            'count': count,
            'pct': round(pct, 2)
        })
    
    return {
        'unique_tokens': int(len(unique)),
        'total_tokens': int(len(real_tokens)),
        'top_tokens': top_tokens
    }


def run_diagnostics(data_dir: str, output_file: str = None):
    """Run all diagnostic checks."""
    print("=" * 70)
    print("DEVIGN PIPELINE DIAGNOSTIC")
    print("=" * 70)
    print(f"\nData directory: {data_dir}")
    
    # Load vocab and config
    print("\n[1/6] Loading vocabulary and config...")
    vocab = load_vocab(data_dir)
    config = load_config(data_dir)
    id2token = get_id2token(vocab)
    
    pad_id = vocab.get('PAD', vocab.get('<PAD>', 0))
    unk_id = vocab.get('UNK', vocab.get('<UNK>', 1))
    
    print(f"  Vocab size: {len(vocab)}")
    print(f"  PAD ID: {pad_id}")
    print(f"  UNK ID: {unk_id}")
    if config:
        print(f"  Max seq length: {config.get('tokenizer', {}).get('max_seq_length', 'N/A')}")
    
    results = {
        'vocab_size': len(vocab),
        'pad_id': pad_id,
        'unk_id': unk_id,
        'splits': {}
    }
    
    # Process each split
    splits = ['train', 'val', 'test']
    available_splits = [s for s in splits if os.path.exists(os.path.join(data_dir, f'{s}.npz'))]
    
    if not available_splits:
        print("\n[ERROR] No data splits found!")
        return None
    
    print(f"\n[2/6] Loading data splits: {available_splits}")
    
    for split in available_splits:
        print(f"\n{'=' * 50}")
        print(f"SPLIT: {split.upper()}")
        print("=" * 50)
        
        data = load_split_data(data_dir, split)
        input_ids = data['input_ids']
        attention_mask = data['attention_mask']
        labels = data['labels']
        
        print(f"  Shape: {input_ids.shape}")
        print(f"  Labels: {(labels == 0).sum()} non-vul, {(labels == 1).sum()} vul")
        
        # Token stats
        print("\n[3/6] Token Statistics:")
        token_stats = calculate_token_stats(input_ids, attention_mask, pad_id, unk_id)
        print(f"  PAD tokens: {token_stats['pad_count']:,} ({token_stats['pad_pct']:.2f}%)")
        print(f"  UNK tokens: {token_stats['unk_count']:,} ({token_stats['unk_pct']:.2f}% of real tokens)")
        
        # Length distribution
        print("\n[4/6] Sequence Length Distribution:")
        length_dist = calculate_length_distribution(attention_mask, labels)
        
        print(f"  All samples:")
        print(f"    Mean: {length_dist['all']['mean']:.1f} ± {length_dist['all']['std']:.1f}")
        print(f"    Range: [{length_dist['all']['min']}, {length_dist['all']['max']}]")
        print(f"    Quartiles: p25={length_dist['all']['p25']:.0f}, p50={length_dist['all']['p50']:.0f}, p75={length_dist['all']['p75']:.0f}")
        
        print(f"  Non-vulnerable (class 0):")
        print(f"    Count: {length_dist['non_vulnerable']['count']}")
        print(f"    Mean: {length_dist['non_vulnerable']['mean']:.1f} ± {length_dist['non_vulnerable']['std']:.1f}")
        
        print(f"  Vulnerable (class 1):")
        print(f"    Count: {length_dist['vulnerable']['count']}")
        print(f"    Mean: {length_dist['vulnerable']['mean']:.1f} ± {length_dist['vulnerable']['std']:.1f}")
        
        # Token distribution
        print("\n[5/6] Top Tokens (excluding PAD):")
        token_dist = analyze_token_distribution(input_ids, attention_mask, id2token, top_k=15)
        print(f"  Unique tokens: {token_dist['unique_tokens']}")
        for t in token_dist['top_tokens'][:10]:
            print(f"    {t['token']:15s} (ID={t['id']:4d}): {t['count']:7,} ({t['pct']:5.2f}%)")
        
        # Sample sequences
        print("\n[6/6] Sample Sequences:")
        samples = get_sample_sequences(input_ids, attention_mask, labels, id2token, n_samples=3)
        
        print("\n  --- Non-Vulnerable Samples ---")
        for s in samples['non_vulnerable']:
            print(f"  [idx={s['index']}, len={s['length']}]")
            print(f"    {s['tokens'][:200]}...")
        
        print("\n  --- Vulnerable Samples ---")
        for s in samples['vulnerable']:
            print(f"  [idx={s['index']}, len={s['length']}]")
            print(f"    {s['tokens'][:200]}...")
        
        results['splits'][split] = {
            'shape': list(input_ids.shape),
            'token_stats': token_stats,
            'length_distribution': length_dist,
            'token_distribution': token_dist,
            'samples': samples,
        }
    
    # Pos weight calculation (train only)
    if 'train' in available_splits:
        print("\n" + "=" * 50)
        print("CLASS IMBALANCE & POS_WEIGHT")
        print("=" * 50)
        
        train_data = load_split_data(data_dir, 'train')
        pos_weight_info = calculate_pos_weight(train_data['labels'])
        
        print(f"\n  Total samples: {pos_weight_info['n_total']:,}")
        print(f"  Positive (vul): {pos_weight_info['n_positive']:,} ({pos_weight_info['pos_ratio']*100:.2f}%)")
        print(f"  Negative (non-vul): {pos_weight_info['n_negative']:,} ({pos_weight_info['neg_ratio']*100:.2f}%)")
        print(f"\n  Recommended pos_weight: {pos_weight_info['pos_weight']:.4f}")
        print(f"  Usage: {pos_weight_info['recommended_weight_tensor']}")
        
        results['pos_weight'] = pos_weight_info
    
    # Save results
    if output_file:
        with open(output_file, 'w') as f:
            json.dump(results, f, indent=2)
        print(f"\n[OK] Results saved to: {output_file}")
    
    print("\n" + "=" * 70)
    print("DIAGNOSTIC COMPLETE")
    print("=" * 70)
    
    return results


def main():
    parser = argparse.ArgumentParser(description="Diagnostic script for Devign data pipeline")
    parser.add_argument('--data_dir', type=str, default=DEFAULT_DATA_DIR,
                        help=f"Path to processed data directory (default: {DEFAULT_DATA_DIR})")
    parser.add_argument('--output', type=str, default=None,
                        help="Optional: Save results to JSON file")
    
    args = parser.parse_args()
    
    if not os.path.exists(args.data_dir):
        print(f"[ERROR] Data directory not found: {args.data_dir}")
        print("\nPlease specify correct path with --data_dir")
        sys.exit(1)
    
    run_diagnostics(args.data_dir, args.output)


if __name__ == '__main__':
    main()
