# %% [markdown]
# # Dataset Analysis - Devign Final
# 
# Analyze class distribution, token statistics, and baseline model performance.
# This helps diagnose why model only achieves AUC ~0.66.

# %%
import os
import json
import numpy as np
from collections import Counter
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
from sklearn.metrics import roc_auc_score, f1_score, classification_report, confusion_matrix
from tqdm.auto import tqdm

# Environment setup - check Windows paths first
import platform

if platform.system() == 'Windows':
    DATA_DIR = 'f:/Work/C Vul Devign/Dataset/devign_final'
elif os.path.exists('/kaggle'):
    DATA_DIR = '/kaggle/input/devign-final/processed'
else:
    DATA_DIR = '/media/hdi/Hdii/Work/C Vul Devign/Dataset/devign_final'

print(f"Data directory: {DATA_DIR}")

# %% [markdown]
# ## 1. Load Data

# %%
def load_split(split_name: str):
    """Load a data split."""
    path = os.path.join(DATA_DIR, f'{split_name}.npz')
    data = np.load(path, allow_pickle=True)
    tokens = data['input_ids']  # Array of token sequences
    labels = data['labels']     # Array of labels (0 or 1)
    
    # Load vocabulary for decoding
    vocab_path = os.path.join(DATA_DIR, 'vocab.json')
    with open(vocab_path, 'r', encoding='utf-8') as f:
        vocab_data = json.load(f)
    # vocab.json is token->id mapping, reverse it
    idx2token = {int(v): k for k, v in vocab_data.items()}
    
    return tokens, labels, idx2token

train_tokens, train_labels, idx2token = load_split('train')
val_tokens, val_labels, _ = load_split('val')
test_tokens, test_labels, _ = load_split('test')

print(f"Train: {len(train_tokens)} samples")
print(f"Val: {len(val_tokens)} samples")
print(f"Test: {len(test_tokens)} samples")

# %% [markdown]
# ## 2. Class Distribution Analysis

# %%
def analyze_class_distribution(labels, split_name):
    """Analyze class distribution."""
    counter = Counter(labels)
    total = len(labels)
    
    n_vuln = counter[1]
    n_safe = counter[0]
    
    print(f"\n=== {split_name.upper()} Class Distribution ===")
    print(f"Total samples: {total}")
    print(f"Vulnerable (1): {n_vuln} ({100*n_vuln/total:.1f}%)")
    print(f"Non-vulnerable (0): {n_safe} ({100*n_safe/total:.1f}%)")
    print(f"Imbalance ratio (neg/pos): {n_safe/n_vuln:.2f}")
    
    return n_vuln, n_safe

train_vuln, train_safe = analyze_class_distribution(train_labels, 'train')
val_vuln, val_safe = analyze_class_distribution(val_labels, 'val')
test_vuln, test_safe = analyze_class_distribution(test_labels, 'test')

# Overall
total_vuln = train_vuln + val_vuln + test_vuln
total_safe = train_safe + val_safe + test_safe
total = total_vuln + total_safe
print(f"\n=== OVERALL ===")
print(f"Vulnerable: {total_vuln} ({100*total_vuln/total:.1f}%)")
print(f"Non-vulnerable: {total_safe} ({100*total_safe/total:.1f}%)")
print(f"Recommended pos_weight for BCE: {total_safe/total_vuln:.2f}")

# %% [markdown]
# ## 3. Token Statistics

# %%
def analyze_tokens(tokens, labels, idx2token, split_name):
    """Analyze token statistics."""
    lengths = [len(t) for t in tokens]
    
    print(f"\n=== {split_name.upper()} Token Statistics ===")
    print(f"Avg sequence length: {np.mean(lengths):.1f}")
    print(f"Median sequence length: {np.median(lengths):.1f}")
    print(f"Max sequence length: {max(lengths)}")
    print(f"Min sequence length: {min(lengths)}")
    print(f"Sequences at max (512): {sum(1 for l in lengths if l >= 512)}")
    
    # Count DANGEROUS_API tokens
    dangerous_apis = ['API_DANGEROUS', 'API_ALLOC', 'API_FREE', 'API_SIZE', 'API_MEM']
    dangerous_count = 0
    total_tokens = 0
    
    for seq in tokens:
        for tok_id in seq:
            total_tokens += 1
            tok = idx2token.get(tok_id, '<UNK>')
            if any(api in tok for api in dangerous_apis):
                dangerous_count += 1
    
    print(f"Total tokens: {total_tokens}")
    print(f"Dangerous API tokens: {dangerous_count} ({100*dangerous_count/total_tokens:.2f}%)")
    
    # Check UNK rate
    unk_id = 1  # Typically UNK is 1
    unk_count = sum(1 for seq in tokens for tok in seq if tok == unk_id)
    print(f"UNK tokens: {unk_count} ({100*unk_count/total_tokens:.2f}%)")
    
    return lengths

train_lengths = analyze_tokens(train_tokens, train_labels, idx2token, 'train')
val_lengths = analyze_tokens(val_tokens, val_labels, idx2token, 'val')

# %% [markdown]
# ## 4. Baseline Models (TF-IDF + Logistic Regression)
# 
# Oracle recommends running simple baseline to understand signal strength.

# %%
def tokens_to_text(tokens, idx2token):
    """Convert token IDs to text for TF-IDF."""
    texts = []
    for seq in tqdm(tokens, desc="Converting tokens to text"):
        text = ' '.join(idx2token.get(int(tok), '<UNK>') for tok in seq)
        texts.append(text)
    return texts

print("Converting tokens to text for TF-IDF...")
train_texts = tokens_to_text(train_tokens, idx2token)
val_texts = tokens_to_text(val_tokens, idx2token)
test_texts = tokens_to_text(test_tokens, idx2token)

# %%
# TF-IDF Vectorization
print("\nBuilding TF-IDF features...")
tfidf = TfidfVectorizer(
    max_features=10000,
    ngram_range=(1, 2),  # Unigrams and bigrams
    min_df=2,
    max_df=0.95,
    sublinear_tf=True
)

X_train = tfidf.fit_transform(train_texts)
X_val = tfidf.transform(val_texts)
X_test = tfidf.transform(test_texts)

print(f"TF-IDF features: {X_train.shape[1]}")

# %%
# Logistic Regression Baseline
print("\n=== Logistic Regression Baseline ===")
lr = LogisticRegression(
    class_weight='balanced',
    max_iter=1000,
    C=1.0,
    random_state=42
)
lr.fit(X_train, train_labels)

# Predictions
lr_train_probs = lr.predict_proba(X_train)[:, 1]
lr_val_probs = lr.predict_proba(X_val)[:, 1]
lr_test_probs = lr.predict_proba(X_test)[:, 1]

lr_train_preds = lr.predict(X_train)
lr_val_preds = lr.predict(X_val)
lr_test_preds = lr.predict(X_test)

print(f"\nTrain AUC: {roc_auc_score(train_labels, lr_train_probs):.4f}")
print(f"Val AUC: {roc_auc_score(val_labels, lr_val_probs):.4f}")
print(f"Test AUC: {roc_auc_score(test_labels, lr_test_probs):.4f}")

print(f"\nTrain F1: {f1_score(train_labels, lr_train_preds):.4f}")
print(f"Val F1: {f1_score(val_labels, lr_val_preds):.4f}")
print(f"Test F1: {f1_score(test_labels, lr_test_preds):.4f}")

print("\nValidation Classification Report:")
print(classification_report(val_labels, lr_val_preds, target_names=['Non-Vulnerable', 'Vulnerable']))

# %%
# Linear SVM Baseline
print("\n=== Linear SVM Baseline ===")
svm = LinearSVC(
    class_weight='balanced',
    max_iter=10000,
    C=1.0,
    random_state=42
)
svm.fit(X_train, train_labels)

# Predictions (decision function for AUC)
svm_train_scores = svm.decision_function(X_train)
svm_val_scores = svm.decision_function(X_val)
svm_test_scores = svm.decision_function(X_test)

svm_train_preds = svm.predict(X_train)
svm_val_preds = svm.predict(X_val)
svm_test_preds = svm.predict(X_test)

print(f"\nTrain AUC: {roc_auc_score(train_labels, svm_train_scores):.4f}")
print(f"Val AUC: {roc_auc_score(val_labels, svm_val_scores):.4f}")
print(f"Test AUC: {roc_auc_score(test_labels, svm_test_scores):.4f}")

print(f"\nTrain F1: {f1_score(train_labels, svm_train_preds):.4f}")
print(f"Val F1: {f1_score(val_labels, svm_val_preds):.4f}")
print(f"Test F1: {f1_score(test_labels, svm_test_preds):.4f}")

# %% [markdown]
# ## 5. Top Features Analysis

# %%
# Most important features for vulnerability detection
feature_names = tfidf.get_feature_names_out()
coefs = lr.coef_[0]

# Top positive (vulnerable) features
top_vuln_idx = np.argsort(coefs)[-30:][::-1]
print("\n=== Top 30 Features for VULNERABLE ===")
for i, idx in enumerate(top_vuln_idx):
    print(f"{i+1:2d}. {feature_names[idx]:30s} (coef: {coefs[idx]:.4f})")

# Top negative (non-vulnerable) features
top_safe_idx = np.argsort(coefs)[:30]
print("\n=== Top 30 Features for NON-VULNERABLE ===")
for i, idx in enumerate(top_safe_idx):
    print(f"{i+1:2d}. {feature_names[idx]:30s} (coef: {coefs[idx]:.4f})")

# %% [markdown]
# ## 6. Interpretation
# 
# **If baseline AUC is similar to BiGRU (~0.65-0.67)**:
# - Token-level signal is inherently weak
# - Need better representation (graph, transformer, code structure)
# 
# **If baseline AUC is much lower (~0.55-0.60)**:
# - BiGRU is learning something, but regularization or architecture is limiting it
# - Focus on model improvements
# 
# **If baseline AUC is higher (~0.70+)**:
# - BiGRU is failing to capture signal that linear model can find
# - Check preprocessing, vocab, sequence handling

# %%
print("\n" + "="*60)
print("SUMMARY")
print("="*60)

lr_val_auc = roc_auc_score(val_labels, lr_val_probs)
bigru_val_auc = 0.66  # From training history

print(f"Logistic Regression Val AUC: {lr_val_auc:.4f}")
print(f"BiGRU Val AUC (from training): {bigru_val_auc:.4f}")

if abs(lr_val_auc - bigru_val_auc) < 0.05:
    print("\n-> CONCLUSION: Token-level signal is WEAK")
    print("  Recommendations:")
    print("  1. Add graph-based features (data flow, control flow)")
    print("  2. Use pretrained code models (CodeBERT, GraphCodeBERT)")
    print("  3. Multi-slice / MIL approach for function-level labels")
    print("  4. Better anchor statement selection")
elif lr_val_auc < bigru_val_auc - 0.05:
    print("\n-> CONCLUSION: BiGRU captures MORE than linear model")
    print("  Recommendations:")
    print("  1. Current preprocessing is working")
    print("  2. Focus on architecture improvements")
    print("  3. Try transformer-based models")
else:
    print("\n-> CONCLUSION: Linear model captures MORE than BiGRU")
    print("  Recommendations:")
    print("  1. Check BiGRU preprocessing (tokenization, vocab)")
    print("  2. Check sequence handling (padding, truncation)")
    print("  3. Debug model architecture")
