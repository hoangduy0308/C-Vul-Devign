"""
Overfit Test Script - Verify model can learn signal from data.

Purpose:
- Train BiGRU model on 200 samples (100 vulnerable, 100 non-vulnerable)
- If model reaches >95% accuracy → pipeline works, model can learn
- If model cannot overfit → problem with pipeline/labels/features

Usage:
    python overfit_test.py
    
Expected output:
- Epoch-by-epoch loss and accuracy
- Final accuracy should reach >95% (ideally near 100%)
"""

import os
import sys
import json
import random
import numpy as np
from pathlib import Path
from typing import Dict, List, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import DataLoader, Dataset, Subset
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score
from tqdm.auto import tqdm

# Environment setup
if os.path.exists('/kaggle/input'):
    WORKING_DIR = '/kaggle/working'
    DATA_DIR = '/kaggle/input/devign-final/processed'
    sys.path.insert(0, '/tmp/devign_pipeline')
else:
    WORKING_DIR = 'F:/Work/C Vul Devign'
    DATA_DIR = 'F:/Work/C Vul Devign/Dataset/devign_final'
    sys.path.insert(0, 'F:/Work/C Vul Devign/devign_pipeline')

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"Device: {DEVICE}")


def set_seed(seed: int = 42):
    """Set random seed for reproducibility."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def load_data_config(data_dir: str) -> Dict:
    """Load config from preprocessed data."""
    config_path = os.path.join(data_dir, 'config.json')
    if os.path.exists(config_path):
        with open(config_path, 'r') as f:
            return json.load(f)
    return {}


class DevignDataset(Dataset):
    """Simple dataset for overfit test."""
    
    def __init__(self, data_path: str, max_length: int = 512):
        self.max_length = max_length
        
        # Load data - support both .pt and .npz formats
        if data_path.endswith('.npz'):
            data = np.load(data_path)
            self.input_ids = torch.tensor(data['input_ids'], dtype=torch.long)
            self.labels = torch.tensor(data['labels'], dtype=torch.long)
            # Load attention mask if exists, otherwise create from non-padding
            if 'attention_mask' in data:
                self.attention_mask = torch.tensor(data['attention_mask'], dtype=torch.long)
            else:
                self.attention_mask = (self.input_ids != 0).long()
            # Optional: vuln features
            self.vuln_features = torch.tensor(data['features'], dtype=torch.float) if 'features' in data else None
        else:
            data = torch.load(data_path, weights_only=False)
            self.input_ids = data['input_ids']
            self.attention_mask = data['attention_mask']
            self.labels = data['labels']
            self.vuln_features = data.get('features', None)
        
        print(f"Loaded {len(self.labels)} samples from {data_path}")
        
    def __len__(self):
        return len(self.labels)
    
    def __getitem__(self, idx):
        item = {
            'input_ids': self.input_ids[idx][:self.max_length],
            'attention_mask': self.attention_mask[idx][:self.max_length],
            'labels': self.labels[idx],
        }
        if self.vuln_features is not None:
            item['vuln_features'] = self.vuln_features[idx]
        return item


def get_balanced_subset(dataset: Dataset, n_samples: int = 200) -> Subset:
    """
    Get balanced subset with n_samples/2 from each class.
    """
    labels = dataset.labels.numpy() if isinstance(dataset.labels, torch.Tensor) else dataset.labels
    
    pos_indices = np.where(labels == 1)[0]
    neg_indices = np.where(labels == 0)[0]
    
    n_per_class = n_samples // 2
    
    # Sample from each class
    np.random.shuffle(pos_indices)
    np.random.shuffle(neg_indices)
    
    selected_pos = pos_indices[:min(n_per_class, len(pos_indices))]
    selected_neg = neg_indices[:min(n_per_class, len(neg_indices))]
    
    indices = np.concatenate([selected_pos, selected_neg])
    np.random.shuffle(indices)
    
    print(f"Selected {len(selected_pos)} positive, {len(selected_neg)} negative samples")
    
    return Subset(dataset, indices.tolist())


def collate_fn(batch):
    """Collate batch with padding."""
    max_len = max(len(item['input_ids']) for item in batch)
    
    input_ids = torch.zeros(len(batch), max_len, dtype=torch.long)
    attention_mask = torch.zeros(len(batch), max_len, dtype=torch.long)
    labels = torch.zeros(len(batch), dtype=torch.long)
    lengths = torch.zeros(len(batch), dtype=torch.long)
    
    has_features = 'vuln_features' in batch[0]
    if has_features:
        feat_dim = batch[0]['vuln_features'].shape[0]
        vuln_features = torch.zeros(len(batch), feat_dim, dtype=torch.float)
    
    for i, item in enumerate(batch):
        seq_len = len(item['input_ids'])
        input_ids[i, :seq_len] = item['input_ids']
        attention_mask[i, :seq_len] = item['attention_mask']
        labels[i] = item['labels']
        lengths[i] = seq_len
        if has_features:
            vuln_features[i] = item['vuln_features']
    
    result = {
        'input_ids': input_ids,
        'attention_mask': attention_mask,
        'labels': labels,
        'lengths': lengths,
    }
    if has_features:
        result['vuln_features'] = vuln_features
        
    return result


class SimpleBiGRU(nn.Module):
    """
    Simplified BiGRU for overfit test.
    Minimal regularization to maximize overfitting capability.
    """
    
    def __init__(self, vocab_size: int, embed_dim: int = 128, 
                 hidden_dim: int = 128, use_vuln_features: bool = False,
                 vuln_feature_dim: int = 25):
        super().__init__()
        
        self.use_vuln_features = use_vuln_features
        
        # Embedding (no dropout for overfit test)
        self.embedding = nn.Embedding(vocab_size, embed_dim, padding_idx=0)
        
        # BiGRU
        self.gru = nn.GRU(
            embed_dim, hidden_dim,
            num_layers=1,
            bidirectional=True,
            batch_first=True
        )
        
        rnn_out_dim = hidden_dim * 2  # bidirectional
        
        # Simple attention
        self.attention = nn.Sequential(
            nn.Linear(rnn_out_dim, hidden_dim),
            nn.Tanh(),
            nn.Linear(hidden_dim, 1, bias=False)
        )
        
        # Vuln features branch (optional)
        if use_vuln_features:
            self.vuln_mlp = nn.Sequential(
                nn.Linear(vuln_feature_dim, 64),
                nn.ReLU(),
            )
            combined_dim = rnn_out_dim + 64
        else:
            combined_dim = rnn_out_dim
        
        # Classifier (minimal, no dropout)
        self.classifier = nn.Sequential(
            nn.Linear(combined_dim, 64),
            nn.ReLU(),
            nn.Linear(64, 2)
        )
    
    def forward(self, input_ids, attention_mask, vuln_features=None, lengths=None):
        # Embedding
        embedded = self.embedding(input_ids)  # [B, L, E]
        
        # GRU
        rnn_out, _ = self.gru(embedded)  # [B, L, D]
        
        # Attention
        att_scores = self.attention(rnn_out)  # [B, L, 1]
        mask = attention_mask.unsqueeze(-1)
        att_scores = att_scores.masked_fill(mask == 0, -1e4)
        att_weights = F.softmax(att_scores, dim=1)
        context = torch.sum(rnn_out * att_weights, dim=1)  # [B, D]
        
        # Combine with vuln features
        if self.use_vuln_features and vuln_features is not None:
            vuln_out = self.vuln_mlp(vuln_features)
            context = torch.cat([context, vuln_out], dim=1)
        
        # Classify
        logits = self.classifier(context)
        return logits


def train_overfit(n_samples: int = 200, epochs: int = 100, 
                  batch_size: int = 32, lr: float = 1e-3):
    """
    Train model on small subset to verify overfitting capability.
    """
    set_seed(42)
    
    # Load config
    data_config = load_data_config(DATA_DIR)
    vocab_size = data_config.get('vocab_size', 30000)
    use_vuln_features = data_config.get('n_features', 0) > 0
    vuln_feature_dim = data_config.get('n_features', 25)
    
    print(f"\n{'='*60}")
    print(f"OVERFIT TEST - {n_samples} samples, {epochs} epochs")
    print(f"{'='*60}")
    print(f"vocab_size: {vocab_size}")
    print(f"use_vuln_features: {use_vuln_features} (dim={vuln_feature_dim})")
    print(f"batch_size: {batch_size}, lr: {lr}")
    print(f"{'='*60}\n")
    
    # Load training data - try .npz first, then .pt
    train_path = os.path.join(DATA_DIR, 'train.npz')
    if not os.path.exists(train_path):
        train_path = os.path.join(DATA_DIR, 'train.pt')
    if not os.path.exists(train_path):
        print(f"ERROR: {train_path} not found!")
        return
    
    dataset = DevignDataset(train_path)
    subset = get_balanced_subset(dataset, n_samples)
    
    loader = DataLoader(
        subset, batch_size=batch_size, 
        shuffle=True, collate_fn=collate_fn,
        num_workers=0
    )
    
    # Build model
    model = SimpleBiGRU(
        vocab_size=vocab_size,
        embed_dim=128,
        hidden_dim=128,
        use_vuln_features=use_vuln_features,
        vuln_feature_dim=vuln_feature_dim
    ).to(DEVICE)
    
    print(f"Model parameters: {sum(p.numel() for p in model.parameters()):,}")
    
    # Optimizer & loss
    optimizer = optim.Adam(model.parameters(), lr=lr)
    criterion = nn.CrossEntropyLoss()
    
    # Training loop
    history = []
    
    print(f"\n{'Epoch':>6} | {'Loss':>8} | {'Acc':>8} | {'F1':>8} | {'AUC':>8}")
    print("-" * 50)
    
    for epoch in range(1, epochs + 1):
        model.train()
        total_loss = 0
        all_preds = []
        all_labels = []
        all_probs = []
        
        for batch in loader:
            input_ids = batch['input_ids'].to(DEVICE)
            attention_mask = batch['attention_mask'].to(DEVICE)
            labels = batch['labels'].to(DEVICE)
            vuln_features = batch.get('vuln_features')
            if vuln_features is not None:
                vuln_features = vuln_features.to(DEVICE)
            lengths = batch.get('lengths')
            
            optimizer.zero_grad()
            
            logits = model(input_ids, attention_mask, vuln_features, lengths)
            loss = criterion(logits, labels)
            
            loss.backward()
            optimizer.step()
            
            total_loss += loss.item()
            
            probs = F.softmax(logits, dim=1)[:, 1].detach().cpu().numpy()
            preds = logits.argmax(dim=1).detach().cpu().numpy()
            
            all_preds.extend(preds)
            all_labels.extend(labels.cpu().numpy())
            all_probs.extend(probs)
        
        # Compute metrics
        avg_loss = total_loss / len(loader)
        accuracy = accuracy_score(all_labels, all_preds)
        f1 = f1_score(all_labels, all_preds, zero_division=0)
        
        try:
            auc = roc_auc_score(all_labels, all_probs)
        except ValueError:
            auc = 0.0
        
        history.append({
            'epoch': epoch,
            'loss': avg_loss,
            'accuracy': accuracy,
            'f1': f1,
            'auc': auc
        })
        
        # Print progress every 5 epochs or first/last
        if epoch <= 5 or epoch % 5 == 0 or epoch == epochs:
            print(f"{epoch:>6} | {avg_loss:>8.4f} | {accuracy:>8.4f} | {f1:>8.4f} | {auc:>8.4f}")
        
        # Early success: stop if we hit >99% accuracy
        if accuracy >= 0.99:
            print(f"\n[SUCCESS] Reached {accuracy*100:.1f}% accuracy at epoch {epoch}")
            break
    
    # Final summary
    final_acc = history[-1]['accuracy']
    final_f1 = history[-1]['f1']
    final_auc = history[-1]['auc']
    
    print(f"\n{'='*60}")
    print("OVERFIT TEST RESULTS")
    print(f"{'='*60}")
    print(f"Final Accuracy: {final_acc*100:.2f}%")
    print(f"Final F1:       {final_f1*100:.2f}%")
    print(f"Final AUC:      {final_auc:.4f}")
    print()
    
    if final_acc >= 0.95:
        print("[SUCCESS] Model CAN overfit on training data")
        print("  -> Pipeline and features are working correctly")
        print("  -> Issue is likely generalization, not signal learning")
    elif final_acc >= 0.80:
        print("[PARTIAL] Model learns some signal but doesn't fully overfit")
        print("  -> Check: learning rate, model capacity, or feature quality")
    else:
        print("[FAILURE] Model CANNOT overfit")
        print("  -> Possible issues:")
        print("    - Labels may be random/incorrect")
        print("    - Features may be uninformative")
        print("    - Tokenization/preprocessing may be broken")
        print("    - Model architecture may have bugs")
    
    print(f"{'='*60}")
    
    return history


if __name__ == "__main__":
    # Run overfit test
    history = train_overfit(
        n_samples=200,  # 100 vulnerable, 100 non-vulnerable
        epochs=100,     # Enough epochs to fully overfit
        batch_size=32,  # Small batch for 200 samples
        lr=1e-3         # Standard learning rate
    )
