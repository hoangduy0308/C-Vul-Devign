"""Tests for devign_pipeline"""
