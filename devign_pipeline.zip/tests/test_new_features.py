"""Test script for new PDG slicer and tokenizer features."""

import sys
sys.path.insert(0, 'F:/Work/C Vul Devign/devign_pipeline')

from src.slicing.pdg_slicer import PDGSlicer, PDGSliceConfig, PDGSliceType
from src.tokenization.preserve_tokenizer import (
    PreserveIdentifierTokenizer, 
    vectorize_preserve,
    TruncationStrategy
)


def test_sep_normalization():
    """Test SEP normalization on fragmented input."""
    print("=== Test SEP Normalization ===")
    
    config = PDGSliceConfig(
        normalize_separators=True,
        min_tokens_between_sep=6,
        max_sep_ratio=0.08,
        insert_separators=True,
        separator_token="[SEP]",
    )
    slicer = PDGSlicer(config)
    
    # Fragmented code with many small segments
    fragmented_code = """int x = 1;
[SEP]
int y = 2;
[SEP]
[SEP]
int z = 3;
[SEP]
return x + y + z;"""
    
    normalized = slicer._normalize_separators(fragmented_code, config)
    
    sep_count = normalized.count("[SEP]")
    print(f"  Original SEPs: {fragmented_code.count('[SEP]')}")
    print(f"  Normalized SEPs: {sep_count}")
    print(f"  Normalized code:\n{normalized}\n")
    
    # Check consecutive SEPs are collapsed
    assert "[SEP]\n[SEP]" not in normalized, "Consecutive SEPs should be collapsed"
    print("  [OK] Consecutive SEPs collapsed")
    
    return True


def test_deduplication():
    """Test deduplication on repeated calls."""
    print("=== Test Deduplication ===")
    
    config = PDGSliceConfig(
        deduplicate_statements=True,
        max_duplicate_calls=2,
        separator_token="[SEP]",
    )
    slicer = PDGSlicer(config)
    
    # Code with repeated fprintf calls
    code_with_dups = """fprintf ( stderr , STR ) [SEP] fprintf ( stderr , STR ) [SEP] fprintf ( stderr , STR ) [SEP] fprintf ( stderr , STR ) [SEP] free ( ptr )"""
    
    deduped = slicer._deduplicate_statements(code_with_dups, config)
    
    fprintf_count = deduped.count("fprintf")
    print(f"  Original fprintf count: {code_with_dups.count('fprintf')}")
    print(f"  After dedup fprintf count: {fprintf_count}")
    print(f"  Deduped code: {deduped}\n")
    
    assert fprintf_count <= config.max_duplicate_calls, f"Should have at most {config.max_duplicate_calls} duplicates"
    assert "free" in deduped, "Non-duplicate calls should be preserved"
    print("  [OK] Deduplication works correctly")
    
    return True


def test_truncation_strategy():
    """Test head_tail truncation strategy."""
    print("=== Test HEAD+TAIL Truncation ===")
    
    tokenizer = PreserveIdentifierTokenizer()
    vocab = {"PAD": 0, "UNK": 1, "CLS": 2, "MASK": 3, "SEP": 4}
    for i, tok in enumerate(["int", "x", "=", "1", ";", "return", "0"], start=5):
        vocab[tok] = i
    
    # Create long token sequence
    tokens = ["int", "x", "=", "1", ";"] * 100 + ["return", "0", ";"]
    
    # Test head_tail truncation
    input_ids, attention_mask, unk_pos = vectorize_preserve(
        tokens, vocab, max_len=20,
        truncation_strategy='head_tail',
        head_tokens=8,
        tail_tokens=10
    )
    
    print(f"  Original length: {len(tokens)}")
    print(f"  Truncated length: {sum(attention_mask)}")
    print(f"  Input IDs (first 10): {input_ids[:10]}")
    print(f"  Input IDs (last 10): {input_ids[-10:]}")
    
    # The SEP token should be inserted
    assert vocab["SEP"] in input_ids, "SEP should be inserted between head and tail"
    print("  [OK] HEAD+TAIL truncation with SEP insertion works")
    
    return True


def test_no_import_errors():
    """Test that all imports work correctly."""
    print("=== Test Imports ===")
    
    try:
        from src.slicing.pdg_slicer import (
            PDGSlicer, PDGSliceConfig, PDGSliceType, PDGSliceResult
        )
        print("  [OK] PDG slicer imports")
        
        from src.tokenization.preserve_tokenizer import (
            PreserveIdentifierTokenizer,
            build_preserve_vocab,
            vectorize_preserve,
            vectorize_batch_preserve,
            TruncationStrategy,
            FORCE_KEEP_IDENTIFIERS,
            PRESERVED_NUMBERS,
        )
        print("  [OK] Preserve tokenizer imports")
        
        # Verify TruncationStrategy enum values
        assert TruncationStrategy.BACK.value == 'back'
        assert TruncationStrategy.FRONT.value == 'front'
        assert TruncationStrategy.HEAD_TAIL.value == 'head_tail'
        print("  [OK] TruncationStrategy enum")
        
        return True
    except ImportError as e:
        print(f"  [FAIL] Import error: {e}")
        return False


def test_full_slice_pipeline():
    """Test full slicing pipeline with new config."""
    print("=== Test Full Pipeline ===")
    
    config = PDGSliceConfig(
        slice_type=PDGSliceType.BIDIRECTIONAL,
        backward_depth=2,
        forward_depth=1,
        normalize_separators=True,
        min_tokens_between_sep=6,
        max_sep_ratio=0.08,
        deduplicate_statements=True,
        max_duplicate_calls=2,
        preserve_defense_statements=True,
        min_slice_tokens=40,
        control_predicate_only=False,
    )
    
    slicer = PDGSlicer(config)
    
    test_code = '''static int process_data(char *buf, int len) {
    char *ptr = malloc(len);
    if (ptr == NULL) {
        return -1;
    }
    memcpy(ptr, buf, len);
    ptr[len] = 0;  // BUG: off-by-one
    free(ptr);
    return 0;
}'''
    
    result = slicer.slice(test_code, [7])
    
    print(f"  Original lines: {len(test_code.split(chr(10)))}")
    print(f"  Slice lines: {len(result.code.split(chr(10)))}")
    print(f"  Used fallback: {result.used_fallback}")
    print(f"  Sliced code:\n{result.code}\n")
    
    assert result.code, "Slice should not be empty"
    print("  [OK] Full pipeline works")
    
    return True


if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("TESTING NEW PIPELINE FEATURES")
    print("=" * 60 + "\n")
    
    results = []
    
    results.append(("Imports", test_no_import_errors()))
    results.append(("SEP Normalization", test_sep_normalization()))
    results.append(("Deduplication", test_deduplication()))
    results.append(("HEAD+TAIL Truncation", test_truncation_strategy()))
    results.append(("Full Pipeline", test_full_slice_pipeline()))
    
    print("\n" + "=" * 60)
    print("TEST RESULTS")
    print("=" * 60)
    
    all_passed = True
    for name, passed in results:
        status = "PASS" if passed else "FAIL"
        print(f"  {name}: {status}")
        if not passed:
            all_passed = False
    
    print("\n" + "=" * 60)
    if all_passed:
        print("ALL TESTS PASSED!")
    else:
        print("SOME TESTS FAILED!")
    print("=" * 60)
